package esercizio1;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int a, b;
		Scanner inp = new Scanner(System.in);
		
		System.out.println("inserisci il numero di thread che vuoi creare: ");
		a = inp.nextInt();
		System.out.println("inserisci il numero fino a cui deve contare: ");
		b = inp.nextInt();
		
		Contatore arr[] = new Contatore[a];
		double rand;
		boolean check = true;
		
		for(int i = 0; i < a; i++) {
			rand = Math.random() * b;
			int num = (int)rand;
			arr[i] = new Contatore(num);
			Thread t = new Thread(arr[i]);
			t.start();
		}
		
		while(check) {
			for(int i = 0; i < a; i++) {
				arr[i].getCont();
				//System.out.println(arr[i].getFine());
				//if(arr[i].getFine() == a) check = false;
			}
			try {
				Thread.sleep(1000);
			}catch (Exception e) {}
			
		}
		
		System.out.println("TUTTI I THREAD SONO TERMINATI");
		
	}

}
