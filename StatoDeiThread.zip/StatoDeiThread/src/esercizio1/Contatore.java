package esercizio1;

public class Contatore implements Runnable {
	
	private int val;
	private int cont;
	private int fine;
	
	public Contatore(int n) {
		val = n;
		fine = 0;
		cont = 0;
	}

	public void getCont() {
		if(cont == val) {
			System.out.println("COMPLETATO");
			fine++;
		}else {
			System.out.println("Conto: " + cont);
		}
		
	}
	
	public int getFine() {
		return fine;
	}
	
	public void run() {
		for (int i = 0; i < val; i++) {
			cont = cont + 1;
			try {
				Thread.sleep(120);
			}catch (Exception e) {}
		}
	}

}
