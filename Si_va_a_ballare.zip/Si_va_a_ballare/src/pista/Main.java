package pista;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Disco discoteca = new Disco();
        int numeroPersone = 10; 

        for (int i = 0; i < numeroPersone; i++) {
            new Persone(discoteca).start();
        }

        while (true) {
            try {
                Thread.sleep(1000);  
                System.out.println("Persone dentro la discoteca: " + discoteca.getNumeroPersoneDentro());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
		
	}

}
