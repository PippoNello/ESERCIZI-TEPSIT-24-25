package pista;

import java.util.Random;

public class Persone extends Thread {
	private Disco discoteca;
    private Random random;

    public Persone(Disco discoteca) {
        this.discoteca = discoteca;
        this.random = new Random();
    }

    public void run() {
        try {
            while (true) {
                discoteca.entra();
                Thread.sleep(random.nextInt(5000) + 1000);
                discoteca.esce();
                Thread.sleep(random.nextInt(5000) + 1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
