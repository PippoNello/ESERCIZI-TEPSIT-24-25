package pista;

public class Disco {
	private int personeDentro = 0;

    public synchronized void entra() {
        personeDentro++;
    }

    public synchronized void esce() {
        personeDentro--;
    }

    public synchronized int getNumeroPersoneDentro() {
        return personeDentro;
    }
}
